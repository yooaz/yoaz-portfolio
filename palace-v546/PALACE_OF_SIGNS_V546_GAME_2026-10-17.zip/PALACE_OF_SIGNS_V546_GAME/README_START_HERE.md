# PALACE OF SIGNS — V546

Open PALACE_OF_SIGNS_V546_PLAY_NOW.html.

Canonical repo: yooaz/palace-of-signs
Branch: dev
V546 keeps V545 run readability/enemy differentiation and adds real-background water reflections, platform lighting and restrained atmosphere.

Physical iPad/Safari runtime: not yet certified.
